//
//  SwiftUIListProjectApp.swift
//  SwiftUIListProject
//
//  Created by KaHa on 27/01/24.
//

import SwiftUI

@main
struct SwiftUIListProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

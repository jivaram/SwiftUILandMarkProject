//
//  ListView.swift
//  SwiftUIListProject
//
//  Created by KaHa on 27/01/24.
//

import SwiftUI

struct ListView: View {
    @State var name: String
    
    init(name: String) {
        self.name = name
    }
    
    var body: some View {
            VStack {
                NavigationLink(destination: CustomView()) {
                    Text(name)
                }
                .navigationBarTitle("List View")
            }
    }
}

#Preview {
    ListView(name: "Jiva Ram")
}

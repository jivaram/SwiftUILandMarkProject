//
//  CustomView.swift
//  SwiftUIListProject
//
//  Created by KaHa on 02/02/24.
//

import SwiftUI

struct CustomView: View {
    @State var count = 10
    
    var body: some View {
        List(0..<10) {_ in 
                ListRowView()
            }.navigationBarTitle("Custom View")
    }
}

#Preview {
    CustomView()
}

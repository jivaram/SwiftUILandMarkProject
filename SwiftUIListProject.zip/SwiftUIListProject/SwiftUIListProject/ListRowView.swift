//
//  ListRowView.swift
//  SwiftUIListProject
//
//  Created by KaHa on 02/02/24.
//

import SwiftUI

struct ListRowView: View {
    var body: some View {
        HStack {
            Text("Name")
            Spacer()
            Image("DSAImage")
                .resizable()
                .frame(width: 50, height: 50)
        }
        .padding()
    }
}

#Preview {
    ListRowView().previewLayout(.fixed(width: 300, height: 70))
        .fixedSize(horizontal: false, vertical: true)
}

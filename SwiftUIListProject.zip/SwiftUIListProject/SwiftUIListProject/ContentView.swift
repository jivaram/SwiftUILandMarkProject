//
//  ContentView.swift
//  SwiftUIListProject
//
//  Created by KaHa on 27/01/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            NavigationLink(destination: ListView(name: "Jiva Ram")) {
                List {
                    Text("List View")
                }
            }
            .navigationTitle("Dynamic List")
        }
    }
}

#Preview {
    ContentView()
}
